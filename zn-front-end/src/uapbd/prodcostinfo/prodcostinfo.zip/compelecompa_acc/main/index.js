//bLkXFuKw3KUaZeb8Dj31ZbW4TYbp/FpJTggm9pjHvEEfh1GZfWjTZgkhzpdZeH65
import {RenderRouter} from 'nc-lightapp-front';
import routes from './router';

(function main(routers,htmlTagid){
  RenderRouter(routers,htmlTagid);
})(routes,"app");


//bLkXFuKw3KUaZeb8Dj31ZbW4TYbp/FpJTggm9pjHvEEfh1GZfWjTZgkhzpdZeH65