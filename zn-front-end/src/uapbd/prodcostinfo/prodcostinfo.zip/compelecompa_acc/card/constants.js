//ZrfLqkdUmeLAaJ0a4DRXMdssDm8zA38iT2bw35yUQAnI+q3Vvau+/iz/tofISw1W
/**
 * 静态文件抽取
 */

/**
 * 页面编码
 */
export const pagecode = '10140CECC_card';


/**
 * 表单区域
 */
export const formId = 'compelecompa_head';

/**
 * 单页应用缓存
 */
export const dataSource  = 'uapbd.prodcostinfo.compelecompa.10140CECC';
/**
 * 单页应用缓存主键名字(主表主键)
 */
export const pkname  = 'pk_compelecompa';
/**
 * 子表主键
 */
export const bodypkname = 'pk_compelecompa_b';
/**
 * 表体区域
 */
export const tableId = 'compelecompa_body';
/**
 * 表体区域-侧拉展开
 */
export const tableId_edit = 'compelecompa_body_form1';
/**
 * 功能节点编码
 */
export const funcode = '10140CECC';
/**
 * 节点编码
 */
export const nodekey = '10140CECC';
/**
 * 单据类型
 */
export const billtype = '10140CECC';
/**
 * 多语文件编码
 */
export const multiLangCode = '10140CECA';
/**
 * 公共多语文件编码
 */
export const cmcommon ='cmcommon';
/**
 * 多语文件模块
 */
export const module = 'uapbd';
/**
 * 页面表格类型
 */
export const tableTypeObj = 'cardTable';

/**
 * 卡片子表肩部按钮区域
 */
export const cardBodyShouler = 'card_body_outer'
/**
 * 卡片子表表体按钮区域
 */
export const cardBodyBody = 'card_body_inner'
/**
 * 数据校验表格类型 form(单个表单) / grid(单个表格) /card(一主一子) /extcard(一主多子)
 */
export const dataValiType = 'card';
/**
 * 导出模块名
 */
export const moduleName = 'uapbd';
/**
 * 导出模块名
 */
export const exprotBillType = 'compelecompa';
/**
 *导入页面pageId
 */
export const importPageId = '10140CECC_import';

//ZrfLqkdUmeLAaJ0a4DRXMdssDm8zA38iT2bw35yUQAnI+q3Vvau+/iz/tofISw1W