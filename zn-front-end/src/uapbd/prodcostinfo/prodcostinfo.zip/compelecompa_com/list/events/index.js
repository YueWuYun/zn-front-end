//bLkXFuKw3KUaZeb8Dj31ZbW4TYbp/FpJTggm9pjHvEEfh1GZfWjTZgkhzpdZeH65
import initTemplate from './initTemplate';
import buttonClick from './buttonClick';
import tableButtonClick from './tableButtonClick';
import doubleClick from './doubleClick';
import pageInfoClick from './pageInfoClick';
import onClickSearchBtn from './onClickSearchBtn';
export {initTemplate,buttonClick,pageInfoClick,tableButtonClick,doubleClick,onClickSearchBtn};

//bLkXFuKw3KUaZeb8Dj31ZbW4TYbp/FpJTggm9pjHvEEfh1GZfWjTZgkhzpdZeH65