//ZrfLqkdUmeLAaJ0a4DRXMdssDm8zA38iT2bw35yUQAnI+q3Vvau+/iz/tofISw1W

/**
 * 查询区域
 */
export const searchId = 'compelecompa_query';
/**
 * 表体区域
 */
export const tableId = 'compelecompa_list';

/**
 * 单页应用缓存
 */
export const dataSource  = 'uapbd.prodcostinfo.compelecompa.10140CECA';
/**
 * 单页应用缓存主键名字
 */
export const pkname  = 'pk_compelecompa';
/**
 * 多语文件编码
 */
export const multiLangCode = '10140CECA';
/**
 * 公共多语文件编码
 */
export const cmcommon ='cmcommon';
/**
 * 页面表格类型
 */
export const tableTypeObj = 'simpleTable';
/**
 * 多语文件模块
 */
export const module = 'uapbd';
/**
 * 单据类型
 */
export const billtype = '10140CECA';
/**
 * 功能节点编码
 */
export const funcode = '10140CECA';
/**
 * 节点编码
 */
export const nodekey = '10140CECA';
/**
 * 列表操作列按钮区域
 */
export const oprarea = 'list_inner_area';
/**
 * 导出模块名
 */
export const moduleName = 'uapbd';
/**
 * 导出模块名
 */
export const exprotBillType = 'compelecompa';
/**
 *导入页面pageId
 */
export const importPageId = '10140CECA_import';

//ZrfLqkdUmeLAaJ0a4DRXMdssDm8zA38iT2bw35yUQAnI+q3Vvau+/iz/tofISw1W