//t062wrAbzsHyGvc+J5WsZFS5JQpJqOhk7tZ3wshRW9fDTY1ZtxRTii9f8OyJs6NJ
import { ajax, toast,promptBox } from 'nc-lightapp-front';
import { pagecode,formId, tableId} from '../constants';

/*
 *表体编辑后事件
 */
export default function bodyAfterEvent(props, moduleId, key, value, changedrows, i, s, g) {
	let that = this;
    //表体编辑后事件
    if (moduleId == tableId) {
        if(changedrows.length > 1){
            props.cardTable.setValByKeyAndIndex(tableId,i,key,{value : value[0].refpk ,display: value[0].refname});
        }
        // ajax({
        //     url: '/nccloud/uapbd/compelecompa/cardbodyafteredit.do',
        //     data: {
        //         rowindex: 0,
        //         editindex: i,
        //         pageId: pagecode,
        //         changedrows: changedrows,
        //         tableId: tableId,
        //         body: props.cardTable.getDataByIndex(tableId, i),
        //         formEvent: props.createFormAfterEventData(pagecode, formId,tableId, key, value),
        //         uiState: that.props.getUrlParam('status')
        //     },
        //     async: false,
        //     success: (res) => {
        //         let {body,head} = res.data;
        //         if (head) {
        //             props.form.setAllFormValue({ [formId]: res.data.head[formId] });
        //         }
        //         if (body) {
        //             if(body[tableId].rows.length > 1){
        //                 let rows = body[tableId].rows;
        //                 let updateBody ={
        //                     areacode :tableId,
        //                     rows :[]
        //                 }
        //                 let insertRows =[]
        //                 rows.forEach(function(value,i){
        //                     if(i == 0){
        //                         updateBody.rows.push(value);
        //                     }else{
        //                         insertRows.push(value);
        //                     }
        //                 })
        //                 props.cardTable.updateDataByRowId(tableId, updateBody);
        //                 props.cardTable.insertRowsAfterIndex(tableId, insertRows,i);
        //             }else{
        //                 props.cardTable.updateDataByRowId(tableId, res.data.body[tableId]);
        //             }
                    
        //         }
		// 		successCallback(that,props, key,changedrows,i);
        //     }
        // });
    }

}
/**
 * 后台处理成功处理
 */
export const successCallback = (that,props, key,changedrows,i) => {
    let body = props.cardTable.getDataByIndex(tableId, i);
    let allRowsNumber = props.cardTable.getNumberOfRows(tableId);
    let cmaterialid = body.values.cmaterialid ? body.values.cmaterialid.value : null; //物料
    if (allRowsNumber == (i + 1) && cmaterialid) {//如果是空白行就不再新增行
        props.cardTable.addRow(tableId,undefined,{'iallocstatus':{value:'0',display:that.state.json['10140CECG-000031']/* 国际化处理： 未分配*/}},false);
    }
};
//t062wrAbzsHyGvc+J5WsZFS5JQpJqOhk7tZ3wshRW9fDTY1ZtxRTii9f8OyJs6NJ